﻿using System.Net;
using MyHttpServer.Framework.Result;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
namespace MyHttpServer.Framework.Services;

public static class EmailService
{
    public static async Task SendEmailAsync(string to, string subject, string body, string attachmentPath)
    {
        var message = new MimeMessage();
        
  
        message.From.Add(new MailboxAddress("Алексей","testmmailtest@mail.ru" ));
        
        message.To.Add(MailboxAddress.Parse(to));
        
        message.Subject = subject;
        
        var builder = new BodyBuilder
        {
            TextBody = body 
        };
        
        if (!string.IsNullOrEmpty(attachmentPath) && File.Exists(attachmentPath))
        {
            await builder.Attachments.AddAsync(attachmentPath);
        }
        
        message.Body = builder.ToMessageBody();
        
       
        using var client = new SmtpClient();
        
        await client.ConnectAsync("smtp.mail.ru", 465, SecureSocketOptions.SslOnConnect);
        

        await client.AuthenticateAsync("testmmailtest@mail.ru", "Xf0sT3c64hZ7zs0BHgbF");
   
        await client.SendAsync(message);
  
        await client.DisconnectAsync(true);
    }
}


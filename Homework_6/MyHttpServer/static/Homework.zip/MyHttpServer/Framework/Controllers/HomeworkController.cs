﻿using MyHttpServer.Framework.Attributes;
using MyHttpServer.Framework.Result;

namespace MyHttpServer.Framework.Controllers;
[Controller("home-work")]
public class HomeworkController : ControllerBase
{
    [Get("send")]
    public IHttpResponseTypeResult Send(string to,string group, string fio)
    {
        try
        {
            string projectPath = Directory.GetCurrentDirectory();
            Console.WriteLine($"Получен запрос на отправку письма на: {to}");
            return Json(new { status = "success", message = $sta"Письмо отправлено: {to},{group}, {fio}"});
        }
        catch (Exception e)
        {
            return Json(new { status = "error", message = e.Message });
        }
        
    }
}